<!DOCTYPE html>
<html>
<head>
    <title>Tambah Produk</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Form Tambah Produk</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        Nama Produk: <input type="text" name="nama_produk" required><br><br>
        Harga Produk: <input type="number" name="harga_produk" required><br><br>
        Jumlah: <input type="number" name="jumlah" required><br><br>
        Gambar Produk: <input type="file" name="gambar_produk" accept="image/*" required><br><br>
        Status: 
        <select name="status" required>
            <option value="ready">ready</option>
            <option value="belum ready">belum ready</option>
        </select><br><br>
        <input type="submit" name="simpan" value="Simpan">
    </form>

    <?php 
    if (isset($_POST['simpan'])) {
        $nama = $_POST['nama_produk'];
        $harga = $_POST['harga_produk'];
        $jumlah = $_POST['jumlah'];
        $status = $_POST['status'];

        // Handle upload gambar
        $nama_file = $_FILES['gambar_produk']['name'];
        $tmp_file = $_FILES['gambar_produk']['tmp_name'];
        $folder = "uploads/";

        // Pindahkan file ke folder tujuan
        if (move_uploaded_file($tmp_file, $folder . $nama_file)) {
            include "modulkoneksi.php";
            $sql = "INSERT INTO tb_produk (produk_name, produk_harga, produk_jumlah, produk_gambar, produk_status) 
                    VALUES ('$nama', '$harga', '$jumlah', '$nama_file', '$status')";
            mysqli_query($koneksi, $sql);
            header("Location: tampil.php");
        } else {
            echo "Upload gambar gagal!";
        }
    }
    ?>
</body>
</html>

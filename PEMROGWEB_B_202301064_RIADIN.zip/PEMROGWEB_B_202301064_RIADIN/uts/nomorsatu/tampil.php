<html>
<head>
  <title>Web CRUD</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php
  include "modulkoneksi.php";
  $sql="SELECT * FROM tb_produk";
  $query=mysqli_query($koneksi,$sql);
  $no=1;
?>
  <table border="1">
    <tr>
        <th>ID Produk</th>
        <th>Nama Produk</th>
        <th>Harga Produk</th>
        <th>Jumlah</th>
        <th>Gambar</th>
        <th>Status</th>
        <th>Opsi</th>
    </tr>
    <?php
        while($data=mysqli_fetch_assoc($query))
        { ?>
            <tr>
            <td><?= $no++ ;?></td>
            <td><?= $data['produk_name'] ?></td>
            <td><?php echo $data['produk_harga'] ?></td>
            <td><?php echo $data['produk_jumlah'] ?></td>
            <td><img src="uploads/<?= $data['produk_gambar'] ?>" width="100" alt="Gambar Produk"></td>
            <td><?php echo $data['produk_status'] ?></td>
            <td>
              <a href="update.php?produk_id=<?= $data['produk_id'] ?>" class="btn-edit">Edit</a>
              <a href="hapus.php?produk_id=<?= $data['produk_id'] ?>" class="btn-hapus">Hapus</a>
            </td>
            </tr>
        <?php } ?> 
  </table>
  <a href="tambah.php" class="tambah-mhs">Tambah Produk</a>
</body>
</html>
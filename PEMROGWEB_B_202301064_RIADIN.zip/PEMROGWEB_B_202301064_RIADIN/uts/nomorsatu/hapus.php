<?php
    $Vidproduk=$_GET['produk_id'];
    include "modulkoneksi.php";
    $sql="DELETE FROM tb_produk WHERE produk_id='$Vidproduk'";
    mysqli_query($koneksi,$sql);
    header("location: tampil.php");
?>

<?php
include 'modulkoneksi.php';
$Vidproduk = $_GET['produk_id'];
$query = "SELECT * FROM tb_produk WHERE produk_id='$Vidproduk'";
$data = $koneksi->query($query)->fetch_assoc();
?>

<head>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Edit Produk</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        Nama Produk: <input type="text" name="nama_produk" value="<?= $data['produk_name'] ?>" required><br><br>
        Harga Produk: <input type="number" name="harga_produk" value="<?= $data['produk_harga'] ?>" required><br><br>
        Jumlah: <input type="number" name="jumlah_produk" value="<?= $data['produk_jumlah'] ?>" required><br><br>
        Gambar Produk Saat Ini: <br>
        <img src="uploads/<?= $data['produk_gambar'] ?>" width="100"><br><br>
        Upload Gambar Baru (kosongkan jika tidak ingin diganti): 
        <input type="file" name="gambar_produk" accept="image/*"><br><br>
        Status: 
        <select name="status" required>
            <option value="ready" <?= ($data['produk_status'] == "ready") ? "selected" : "" ?>>ready</option>
            <option value="belum ready" <?= ($data['produk_status'] == "belum ready") ? "selected" : "" ?>>belum ready</option>
        </select><br><br>
        <input type="submit" name="simpan" value="Simpan">
    </form>

    <?php 
    if (isset($_POST['simpan'])) {
        $nama = $_POST['nama_produk'];
        $harga = $_POST['harga_produk'];
        $jumlah = $_POST['jumlah_produk'];
        $status = $_POST['status'];
        
        $gambarBaru = $_FILES['gambar_produk']['name'];
        $tmp = $_FILES['gambar_produk']['tmp_name'];
        $folder = "uploads/";

        // Jika user upload gambar baru
        if (!empty($gambarBaru)) {
            move_uploaded_file($tmp, $folder . $gambarBaru);
        } else {
            $gambarBaru = $data['produk_gambar']; // tetap gunakan gambar lama
        }

        $sql = "UPDATE tb_produk 
                SET produk_name='$nama',
                    produk_harga='$harga',
                    produk_jumlah='$jumlah',
                    produk_gambar='$gambarBaru',
                    produk_status='$status' 
                WHERE produk_id='$Vidproduk'";
        mysqli_query($koneksi, $sql);
        header("Location: tampil.php");
    }
    ?>
</body>

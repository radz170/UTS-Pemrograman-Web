<?php
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='db_uts_web_b';
$koneksi=mysqli_connect($dbhost,$dbuser,$dbpass,$db);
if (!$koneksi)
{
    echo 'koneksi gagal';
}else{
    #echo 'koneksi berhasil';
}
?>